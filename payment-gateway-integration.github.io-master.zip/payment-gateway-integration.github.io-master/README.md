# payment-gateway-integration
## This is my task 1 for internship under GRIP at Sparks Foundation
###### Payment Gateway Integration is developed using Paypal as the payment gateway
###### Web-Technologies used : HTML,CSS,JS,Bootstrap || Node.js with Express

###### **Please use the Buyer id details provided for logging into the payment gateway**
###### **Please use the Seller id details provided for checking the transaction details in merchant's id and sending invoice**
